jQuery.Feyn is a jQuery plugin for drawing Feynman diagrams with SVG.
For documentation and examples, please visit the project page:
http://photino.github.io/jquery-feyn/.
